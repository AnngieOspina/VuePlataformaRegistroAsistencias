const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let userSchema = new Schema(
  {
    nombre: { type: String },
    apellido: { type: String },
    cedula: { type: Number },
    usuario: { type: String },
    password: { type: String },
    rol: { type: String },
  },
  {
    collection: "users",
  }
);

module.exports = mongoose.model("User", userSchema);
